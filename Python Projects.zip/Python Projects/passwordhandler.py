import string
import random
import shutil
import os
accname = input("Enter your name\n")
while True:
	nex = input("Do wan't to read password file(pf) or genrate a password(gp) or store password(sp) or move passowrds file to another location(mpw)\n")
	if "pf" == nex:
		mypw = []
		try:
			f = open("passwords.txt","r")
			scaner = f.read().split("\n")
			f.close()
			for x in range(len(scaner)):
					inpscan = scaner[x]
					if accname in inpscan:
						mypw.append(inpscan)
			print("here is your passwords " + str(mypw) + "\n")
		except Exception as ex:
			f = open("passwords.txt","a")
			f.close()
	elif "sp" == nex:
		wil = input("What will this password unlock\n")
		pw = input("Enter the password\n")
		add = accname + " | " + pw + " | " + wil
		f = open("passwords.txt","a")
		f.write("\n" + add)
		f.close()
	elif "gp" == nex:
		wil = input("What will this password unlock\n")
		s1 = string.ascii_lowercase
		s2 = string.ascii_uppercase
		s3 = string.digits
		s4 = string.punctuation
		plen = int(input("Enter password length\n"))
		s = []
		s.extend(list(s1))
		s.extend(list(s2))
		s.extend(list(s3))
		s.extend(list(s4))
		pw = "".join(random.sample(s, plen))
		add = accname + " | " + pw + " | " + wil
		f = open("passwords.txt","a")
		f.write("\n" + add)
		f.close()
		print("Your Password is saved like this " + pw + " in passwords.txt\n")
	elif "mpw" == nex:
		moveFolder = input("Enter a location\n")
		if "OneDrive" in moveFolder:
			print("AnyWone can steal these passwords make a new folder to store passwords")
			continue
		else:
			try:
				shutil.move("passwords.txt",moveFolder)
			except:
				print("There was a error moving the file")
	else:
		break
