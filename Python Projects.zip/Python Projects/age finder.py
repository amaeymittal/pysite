# -*- coding: utf-8 -*-
"""
Created on Mon Sep  7 17:48:45 2020

@author: ankita
"""


print("so now I will ask 2 simple qwestions answer them other wise no age")
an=int(input("1:what is the year if your birthday has not been done at last year:"))
a= int(input("2:what is the born year: "))
u = (an-a)
print("you are",u,"years old")
