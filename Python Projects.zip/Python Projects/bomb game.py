# -*- coding: utf-8 -*-
"""
Created on Sat Jul 18 14:57:33 2020

@author: ankita
"""

import tkinter
import random
gameover=False
score=0
squaretoclear =0
def play_bombdoger():
    Create_bombfield(bombfield)
    window = tkinter.Tk()
    layout_window(window)
    window.mainloop()
bombfield = []
def Create_bombfield(bombfield):
   global squaretoclear
   for row in range(0,10):
       rowlist = []
       for column in range(0,10):
           if random.randint(1,100) < 20:
              rowlist.append(1)
           else:
               rowlist.append(0)
               squaretoclear = squaretoclear + 1
       bombfield.append(rowlist)
def printfield(bombfield):
    for rowlist in bombfield:
        print(rowlist)
#play_bombdoger()
def layout_window(Window):
    for rowNumber, rowlist in enumerate(bombfield):
        for columnNumber, columnEntery in enumerate(rowlist):
           if random.randint(1,100) < 25:
              square = tkinter.Label(Window, text="    ", bg = "darkgreen")
           elif random.randint(1,100) > 75:
               square = tkinter.Label(Window, text="    ", bg = "seagreen")
           else:
               square = tkinter.Label(Window, text="    ", bg = "green")
           square.grid(row = rowNumber, column = columnNumber)
           square.bind("<Button-1>", on_click)
#play_bombdoger()
def on_click(event):
    global score
    global gameover
    global squarestoclear
    square = event.widget
    row =int(square.grid_info()["row"])
    column =int(square.grid_info()["column"])
    currentText = square.cget("text")
    print (currentText) #bug check
    if gameover ==False:
        if bombfield[row][column] ==1: 
            gameover = True
            square.config(bg = "red")
            print("boom!! game Over! you hit a bomb and dead")
            print("iq",score)
            print("see the answer")
            printfield(bombfield)
            print("1 means bomb and 0 means safe square")
        elif currentText == "    ":
            print("safe square good job") #bug check
            square.config(bg = "brown")
            totalbomb = 0
            if row < 9:
                if bombfield[row+1][column] ==1:
                    totalbomb = totalbomb +1
            
            if row > 0:
                if bombfield[row-1][column] ==1:
                    totalbomb = totalbomb +1
            if column > 0:
                if bombfield[row][column-1] ==1:
                    totalbomb = totalbomb +1
            if column < 9:
                if bombfield[row][column+1] ==1:
                    totalbomb = totalbomb +1
            if row > 0 and column > 0:
                if bombfield[row-1][column-1] ==1:
                    totalbomb = totalbomb +1
            if row < 9 and column > 0:
                if bombfield[row+1][column-1] ==1:
                    totalbomb = totalbomb +1
            if row > 0 and column < 9:
                if bombfield[row+1][column] ==1:
                    totalbomb = totalbomb +1                    
            if row > 0 and column < 9:
                if bombfield[row+1][column] ==1:
                    totalbomb = totalbomb +1    
            square.config(text = " " + str(totalbomb) + " ") 
            squarestoclear = squaretoclear - 1
            score = score + 24
            if squaretoclear ==0:
                gameover = True
                print("congratulation! you found all safe squares")
                print("iq",score)
play_bombdoger()
