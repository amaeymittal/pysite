# -*- coding: utf-8 -*-
"""
Created on Sun Nov 29 16:49:17 2020

@author: ankita
"""
choice=int(input("how many rounds?"))
pepole1=input("name")
pepole2 = input("name")
score_amaey=0
score_shreya=0
for x in range(0,choice):
    if x==choice-1:
        print("last round over",choice,"is over")
        print("Last Round good luck for your score.score will be displayed press enter to display. ")
    else:
        print("round",x+1) 
    x=int(input(pepole1))
    score_amaey=score_amaey + x
    c=int(input(pepole2))
    score_shreya=score_shreya + c
    e = input("are you sure?")
while e != "y":
    score_shreya=score_shreya + c
    score_amaey2=score_amaey-x
    score_shreya2=score_shreya-c
    a=int(input(pepole1))
    score_amaey=score_amaey2 + a
    a=int(input(pepole2))
    score_shreya=score_shreya2 + a
    e = input("are you sure?")
print(pepole1,score_amaey)
print(pepole2,score_shreya)