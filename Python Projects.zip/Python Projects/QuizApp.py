def AnimalQuiz():
    score = 0
    listofq = ["how many hours does a koala sleep\n 19.5 hours\n 20hours\n 20.5hours\n 21hours","what is the average lifespan of a golden retriver dog\n 9-11 years\n 10-12 years\n 11-13 years\n 12-14years","which story is based on animals\n Panchatantra\n Jataka","which is the fastest bird\n eagle\n vulture\n The Peregrine Falcon\n other species of falcon","what is the maximum speed of a sloth\n 1000m/h\n 500m/h\n 270 m/h"]
    listofa = ["20hours","10-12 years","Panchatantra","The Peregrine Falcon","270 m/h"]
    for x in range(5):
        opt = str(input(listofq[x]))
        if opt == listofa[x]:
            score+=1
            print("Your Answer is correct")
        else:
            score-=1
            print("your answer is wrong")
    print("\nThe Game is Over.\nYour score is",score)
    print("Here is your answers:")
    print(listofa)

def SpaceQuiz():
    score = 0
    listofq = ["Which is the largest planet in our solar system\n Jupiter\n Saturn","Which is the nearest star to our sun\n Alpha Centauri\n Proxima Centauri","Were is the asteroid belt\n Between Mars and Jupiter\n Between Earth and Mars","Which is the hotest planet\n Mercury\n Venus","which sattelite has gone the farthest from earth\n Voyager 1\n Voyager 2"]
    listofa = ["Jupiter","Proxima Centauri","Between Mars and Jupiter","Venus","Voyager 1"]
    for x in range(5):
        opt = str(input(listofq[x]))
        if opt == listofa[x]:
            score+=1
            print("Your Answer is correct")
        else:
            score-=1
            print("your answer is wrong")
    print("\nThe Game is Over.\nYour score is",score)
    print("Here is your answers:")
    print(listofa)

def CapitalQuiz():
    score = 0
    listofq = ["what is the capital of Saudi Arabia\n Riyadh\n Sanas","what is the capital of Iran\n Baghdad\n Tehran","what is the capital of Denmark\n Amsterdam\n Copenhagen","what is the capital of Qatar\n Doha\n Muscat","what is the capital of Slovenia\n Ljubljana\n Prague"]
    listofa = ["Riyadh","Tehran","Copenhagen","Doha","Ljubljana"]
    for x in range(5):
        opt = str(input(listofq[x]))
        if opt == listofa[x]:
            score+=1
            print("Your Answer is correct")
        else:
            score-=1
            print("your answer is wrong")
    print("\nThe Game is Over.\nYour score is",score)
    print("Here is your answers:")
    print(listofa)

#main code
typequiz = input("What type of quiz do you want to play\na.Animal\nb.Space\nc.Country capital\n(answer in option)\n")
# print(type(typequiz)) For debuging purpose
if "a" == typequiz:
    AnimalQuiz()
elif "b" == typequiz:
    SpaceQuiz()
elif "c" == typequiz:
    CapitalQuiz()
else:
    print("Sorry this is a invalid option")