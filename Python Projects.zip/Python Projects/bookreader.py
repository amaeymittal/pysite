# -*- coding: utf-8 -*-
"""
Created on Thu Aug  5 16:29:24 2021

@author: ankita
"""
import pyttsx3
import PyPDF2
a=input("file please")
book = open(a,"rb")
reader = PyPDF2.PdfFileReader(book)
pages = reader.getNumPages()
print(pages)
page = reader.getPage(0)
text = page.extractText()
speak = pyttsx3.init()
speak.say(text)
speak.runAndWait()

