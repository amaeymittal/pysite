# -*- coding: utf-8 -*-
"""
Created on Sat Jul 11 16:53:17 2020

author: ankita
"""

choice = int(input("how much rounds:"))
pepole1=input("name")
pepole2=input("name")
pepole3=input("name")
pepole4=input("name")
score_amaey=0
score_shreya=0
score_ankita=0
score_abhinit=0
for x in range(0,choice):
    if x==choice-1:
        print("last round over",choice,"is over")
        print("Last Round good luck for your score.score will be displayed press enter to display. ")
    else:
        print("round",x+1) 
    x=int(input(pepole1))
    score_amaey=score_amaey + x
    c=int(input(pepole2))
    score_shreya=score_shreya + c
    p=int(input(pepole3))
    score_ankita = score_ankita+p
    o=int(input(pepole4))
    score_abhinit =score_abhinit + o
    e = input("are you sure?")
while e != "y":
    score_amaey2=score_amaey-x
    score_shreya2=score_shreya-c
    score_ankita2=score_ankita-p
    score_abhinit2=score_abhinit-o
    a=int(input(pepole1))
    score_amaey=score_amaey2 + a
    a=int(input(pepole2))
    score_shreya=score_shreya2 + a
    a=int(input(pepole3))
    score_ankita = score_ankita2+a
    a=int(input(pepole4))
    score_abhinit = score_abhinit2 + a
    e = input("are you sure?")
print(pepole1,score_amaey)
print(pepole2,score_shreya)
print(pepole3,score_ankita)
print(pepole4,score_abhinit)
