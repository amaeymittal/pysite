# -*- coding: utf-8 -*-
"""
Created on Wed May 20 17:26:02 2020

@author: ankita
"""

print("you are in a dark room in a mysterious catsle")
print("In front of you are three doors choose one")
player_choice = input("choose 1,2 or 3 ...")
if player_choice=="1":
    print("you find a room full of treasure.")
    print("GAME OVER ,YOU WIN")
elif player_choice=="2":
     print("the door opens and an angry ogre hits you with his club")
     print("GAME OVER.YOU LOSE")
elif player_choice=="3":
    print("you go into the room and find a sleeping dragon")
    print("the dragon wakes up and eat you")
    print("GAME OVER.YOU LOSE")           
    