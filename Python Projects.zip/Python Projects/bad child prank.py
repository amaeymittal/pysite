import playsound2
input("who is a bad child?\n")
while True :
    print("you are a bad child")
    playsound2.playsound("Recording-_22_.mp3")