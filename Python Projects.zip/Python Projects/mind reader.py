import random as rd
n = [1,2,3,4,5,6,7,8,9,10]
wrong = 0
choice = int(input("which number I am thinking from 1-10"))
number = rd.choice(n)
while number != choice:
    if number > choice:
        print("the number is to small")
        choice = int(input("try again"))
        wrong = wrong + 1
    if number < choice:
        print("the number is to large")
        choice = int(input("try again"))
        wrong = wrong + 1
    if number == choice:
        print("cograts it is the correct number you did in ",wrong,"times")
