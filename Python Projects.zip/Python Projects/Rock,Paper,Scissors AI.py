import random as rd
score = 0
aiscore = 0
rounds = int(input("How many rounds do you want to play\n"))
for loop in range(rounds):
    opt = input("Rock Paper or Scissor")
    AI = rd.choice(["Rock" , "Paper" , "Scissor" ])
    print(AI)
#"Paper>Rock" , "Rock>Scissors" , "Scissors>Paper"
    if opt=="Paper"and AI =="Rock":
        print("you win")
        score = score + 1
    elif opt=="Rock" and AI =="Scissor":
        print("you win")
        score = score + 1
    elif opt== "Scissor" and AI == "Paper":
        print("you win")
        score = score + 1
    elif opt==AI:
        print("draw")
    else:
        print("you lose")
        aiscore = aiscore + 1
print("game over")
print("Your score is\n",score)
print("And Coumputer score is\n",aiscore)
