# -*- coding: utf-8 -*-
"""
Created on Wed Sep  9 13:43:19 2020

@author: ankita
"""


aw=str(input("welcome to smart banking expirence what you need ATM or bank?"))
def ATM():
    x=int(input("ok how much moeny you have?"))
    t=int(input("how much moeny you need?"))
    b=(x + t)
    print("here is your",t,"and your widral balance is",b)
def bank():
    c = int(input("ok how much moeny you have?"))
    y = int(input("how much moeny you need to deposit?"))
    n = (c+y)
    print("now your balance is ",n)
if aw == "ATM":
    ATM()
if aw == "bank":
    bank()
