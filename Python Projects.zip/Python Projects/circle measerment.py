# -*- coding: utf-8 -*-
"""
Created on Thu Sep 10 16:43:40 2020

@author: ankita
"""


pi = (3.14)
a = str(input("what you need curncunference,area of the circle?"))
def curncunference():
    vb=int(input("ok what is the damater of the circle?"))
    f1 = (pi*vb)
    print("curncunfrence of this circle is",f1)
def area():
    er=int(input("ok what is the ruidus of the circle?"))
    f2 = (pi*er*er)
    print("area of this circle is",f2)
if a == "curncunference":
    curncunference()
if a == "area":
    area()