# -*- coding: utf-8 -*-
"""
Created on Sat Aug  7 09:24:00 2021

@author: ankita
"""

# head of writepad
from tkinter import *
from tkinter.filedialog import asksaveasfilename,askopenfilename
from datetime import datetime
Window = Tk()
Window.title("Writepad")
Window.geometry("800x400")
file_path = ""
font = "15"
# TextArea of writepad
TextArea = Text(Window,font=f"Tahoma {font}")
#functions of Writepad
def set_file_path(path):
    global file_path
    file_path = path

def new():
    TextArea.delete("1.0",END)
def save_as():
    if file_path == "":
       path = asksaveasfilename(filetypes=[("textfile","*.txt"),("All files","*.*")])
    else:
        path = file_path
    with open(path,"w") as file:
        code = TextArea.get("1.0",END)
        file.write(code)
        set_file_path(path)
def opens():
    path = askopenfilename(filetypes=[("textfile","*.txt"),("All files","*.*")])
    with open(path,"r") as file:
        code = file.read()
        TextArea.delete("1.0",END)
        TextArea.insert("1.0",code)
        set_file_path(path)
def cut():
    TextArea.event_generate(("<<Cut>>"))
def copy():
    TextArea.event_generate(("<<Copy>>"))
def paste():
    TextArea.event_generate(("<<Paste>>"))
def wt():
    TextArea.insert("1.0",datetime.now().strftime("%H:%M  %d-%m-%Y"))
        
menu = Menu(Window)
file_bar = Menu(menu,tearoff=0)
file_bar.add_command(label="New",command=new)
file_bar.add_command(label="Open",command=opens)
file_bar.add_command(label="Save",command=save_as)
file_bar.add_command(label="Exit",command=Window.quit)
menu.add_cascade(label="File",menu=file_bar)

Edit_bar = Menu(menu,tearoff=0)
Edit_bar.add_command(label="Cut",command=cut)
Edit_bar.add_command(label="Copy",command=copy)
Edit_bar.add_command(label="Paste",command=paste)
Edit_bar.add_command(label="Date-and_time",command=wt)
menu.add_cascade(label="Edit",menu=Edit_bar)

#Pack all Elements
Window.config(menu=menu)
TextArea.pack(fill=X)

Window.mainloop()